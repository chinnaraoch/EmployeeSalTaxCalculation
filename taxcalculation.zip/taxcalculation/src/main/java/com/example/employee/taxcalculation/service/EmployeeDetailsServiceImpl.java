package com.example.employee.taxcalculation.service;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.example.employee.taxcalculation.exception.InvalidEmployeeDetailsInputException;
import com.example.employee.taxcalculation.model.EmployeeDetailsModel;
import com.example.employee.taxcalculation.pojo.EmployeeDetailsPojo;
import com.example.employee.taxcalculation.pojo.SalaryPojo;

@Service
public class EmployeeDetailsServiceImpl implements EmployeeDetailsService {

	@Override
	public boolean saveEmployee(EmployeeDetailsPojo employeeDetailsPojo) throws InvalidEmployeeDetailsInputException{
		// TODO Auto-generated method stub
		if(employeeDetailsPojo!=null) {
			if(validateEmployeeDetails(employeeDetailsPojo)) {
				//need to fill EmployeeDetailsModol object and save
			}
		}else {
			throw new InvalidEmployeeDetailsInputException("Employee Details are required.", null);
		}
		
		
		return false;
	}
	
	
	private boolean validateEmployeeDetails(EmployeeDetailsPojo employeeDetails) throws InvalidEmployeeDetailsInputException {
		
		if(StringUtils.isEmpty(employeeDetails.getFirstName()))
			throw new InvalidEmployeeDetailsInputException("Firstname is required.", null);
		
		if(StringUtils.isEmpty(employeeDetails.getLastName()))
			throw new InvalidEmployeeDetailsInputException("LastName is required.", null);
		
		if(StringUtils.isEmpty(employeeDetails.getEmail()))
			throw new InvalidEmployeeDetailsInputException("Email is required.", null);
		else {
			 //Regular Expression   
	        String regex = "^(.+)@(.+)$";  
	        //Compile regular expression to get the pattern  
	        Pattern pattern = Pattern.compile(regex);
	        Matcher matcher = pattern.matcher(employeeDetails.getEmail());  
	        if(!matcher.matches())
	        	throw new InvalidEmployeeDetailsInputException("Given Email is invalid.", null);	
		}
		
		if(employeeDetails.getPhoneNumbers()==null || employeeDetails.getPhoneNumbers().size()==0)
			throw new InvalidEmployeeDetailsInputException("PhoneNumber is required.", null);
		
		if(employeeDetails.getDoj()==null)
			throw new InvalidEmployeeDetailsInputException("DOJ is required.", null);
		
		if(employeeDetails.getSalary()==0)
			throw new InvalidEmployeeDetailsInputException("Salary is required.", null);
		
		
		return Boolean.TRUE;
	}


	@Override
	public SalaryPojo fetchEmployeeTaxDetails(String employeeCode) throws InvalidEmployeeDetailsInputException{
		// TODO Auto-generated method stub
		SalaryPojo salaryDetails = new SalaryPojo();
		if(!StringUtils.isEmpty(employeeCode)) {
			//get employeedetails from the database based on employeecode
			
			EmployeeDetailsModel employeeDetails = new EmployeeDetailsModel();
			
			salaryDetails.setEmployeeCode(employeeCode);
			salaryDetails.setFirstName(employeeDetails.getFirstName());
			salaryDetails.setLastName(employeeDetails.getLastName());
			
			double currentYearSalary = calculateYearlySalary( employeeDetails);
			salaryDetails.setYearlySalary(currentYearSalary);
			double taxAmount = calculateTax( currentYearSalary);
			salaryDetails.setTaxAmount(taxAmount);
			
			double cessAmount = calculateCess(currentYearSalary);
			salaryDetails.setCessAmount(cessAmount);
			
			
		}else {
			throw new InvalidEmployeeDetailsInputException("EmployeeCode is required.", null);
		}
		
		return salaryDetails;
	}

	private double calculateYearlySalary(EmployeeDetailsModel employeedata) {
		double currentyearsalary=0;
		if(employeedata.getDoj().after(new Date(2022,03,31))) {
			
			int joinedMonth = employeedata.getDoj().getMonth();
			
			int remainingMonths = 0;
			
			if(joinedMonth>3)
				remainingMonths=12-joinedMonth+2;
			else
				remainingMonths=4-joinedMonth;
			
			int remainingdays =30- employeedata.getDoj().getDay();
			double remainingMonthsSalary = employeedata.getSalary()*remainingMonths;
			double perdaysal=employeedata.getSalary()/30;
			double daysSal = perdaysal*remainingdays;
			currentyearsalary = daysSal+remainingMonthsSalary;
		}else {
			currentyearsalary=employeedata.getSalary()*12;
			
		}
		return currentyearsalary;
	}
	
	private double calculateTax(double salary) {
		
		if(salary<=250000) {
			return 0;
		}else if(salary>250000 && salary<=500000) {
			double calculatetax=salary-250000;
			return calculatetax*0.05;
		}else if(salary>500000 && salary<=1000000) {
			double calculatetax=salary-250000;
			return calculatetax*0.10;
		}else {
			double calculatetax=salary-250000;
			return calculatetax*0.20;
		}
			
		
	}
	private double calculateCess(double salary) {
		
		if(salary<= 2500000) {
			return 0;
		}else {
			double calAmount = salary-2500000;
			return calAmount*0.02;
		}
			
		
	}

}
