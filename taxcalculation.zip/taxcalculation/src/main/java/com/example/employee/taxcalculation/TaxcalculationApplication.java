package com.example.employee.taxcalculation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxcalculationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaxcalculationApplication.class, args);
	}

}
