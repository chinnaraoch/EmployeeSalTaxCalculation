package com.example.employee.taxcalculation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.employee.taxcalculation.exception.InvalidEmployeeDetailsInputException;
import com.example.employee.taxcalculation.pojo.EmployeeDetailsPojo;
import com.example.employee.taxcalculation.pojo.SalaryPojo;
import com.example.employee.taxcalculation.service.EmployeeDetailsService;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeDetailsService employeeDetailsService;
	
	@PostMapping(value ="v1/saveEmployee" )
	public String saveEmployeeData(@RequestBody EmployeeDetailsPojo employeeDetails) throws InvalidEmployeeDetailsInputException {
		
		boolean status=employeeDetailsService.saveEmployee(employeeDetails);
		if(status)
		return "Employee Created Successfully.";
		else
			return "Employee not Created.";
	}
	
	@GetMapping(value ="v1/fetchEmployeeTaxdetails")
	public SalaryPojo getEmployeeTaxDetails(@RequestParam("employeecode")String employeecode) throws InvalidEmployeeDetailsInputException {
		return employeeDetailsService.fetchEmployeeTaxDetails(employeecode);
		
	}
	

}
