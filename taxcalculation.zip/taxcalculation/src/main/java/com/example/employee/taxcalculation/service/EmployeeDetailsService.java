package com.example.employee.taxcalculation.service;

import com.example.employee.taxcalculation.exception.InvalidEmployeeDetailsInputException;
import com.example.employee.taxcalculation.pojo.EmployeeDetailsPojo;
import com.example.employee.taxcalculation.pojo.SalaryPojo;

public interface EmployeeDetailsService {

	public boolean saveEmployee(EmployeeDetailsPojo employeeDetailsPojo) throws InvalidEmployeeDetailsInputException;

	public SalaryPojo fetchEmployeeTaxDetails(String employeeCode) throws InvalidEmployeeDetailsInputException;
}
