package com.example.employee.taxcalculation.exception;

public class InvalidEmployeeDetailsInputException extends Exception {

	public InvalidEmployeeDetailsInputException(String message,Throwable cause){
		super(message,cause);
	}
	
}
